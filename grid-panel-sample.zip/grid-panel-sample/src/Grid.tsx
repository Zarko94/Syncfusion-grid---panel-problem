import { Panel, PanelType } from '@fluentui/react';
import { ColumnDirective, ColumnsDirective, Filter, GridComponent, Group, Inject, Page, PageSettingsModel, Sort } from '@syncfusion/ej2-react-grids';
import * as React from 'react';
import { useEffect, useState } from 'react';
import data from './data';
import { initializeIcons } from '@fluentui/react/lib/Icons';

const Grid=()=> {
    const [openDummyPanel,setOpenDummyPanel]=useState(false)
    const onDummyPanelDismiss =()=>{setOpenDummyPanel(false)}
    const openPanelOnLinkClick=(ev:any,service:any)=>{setOpenDummyPanel(true)}
    useEffect(()=>{
        initializeIcons()
    },[])
const pageSettings: PageSettingsModel = { pageSize: 6 }
    return (
    <>
    <GridComponent dataSource={data} allowPaging={true} pageSettings={ pageSettings } selectionSettings={{mode: "Row", type: 'Single', allowColumnSelection:true}}>
    <ColumnsDirective>
        <ColumnDirective field='OrderID' width='100' textAlign="Right"template={(service:any) => {
            console.log('klik') 
                                                 return <a className={"panelOpener"}
                                                 onClick={(ev) => openPanelOnLinkClick(ev, service)}
                                                 href={"#"}>{service.OrderID}</a>;
                                                }} />
        <ColumnDirective field='CustomerID' width='100'/>
        <ColumnDirective field='EmployeeID' width='100' textAlign="Right"/>
        <ColumnDirective field='Freight' width='100' format="C2" textAlign="Right"/>
        <ColumnDirective field='ShipCountry' width='100'/>
    </ColumnsDirective>
    <Inject services={[Page, Sort, Filter, Group]} />
</GridComponent>
    <Panel
                            isOpen={openDummyPanel}
                            onDismiss={() => onDummyPanelDismiss()}
                            type={PanelType.medium}
                            closeButtonAriaLabel="Close"
                            headerText="Installation Details"
                        >
                            {
                             <h1>Opened</h1>
                            }

                        </Panel>
    </>
    )
};
export default Grid